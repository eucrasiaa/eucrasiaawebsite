function discord_nv
    # Usage: discord_nv input.mp4 [quality_num]
    # Default quality is 28. Higher number = smaller file/lower quality.
    set -l quality 28
    if test (count $argv) -ge 2
        set quality $argv[2]
    end

    set -l extension (string split -r -m1 . $argv[1])[2]
    set -l output (string replace -r "\.$extension\$" "_discord.mp4" $argv[1])

    ffmpeg -y -i $argv[1] \
        -c:v h264_nvenc \
        -preset p6 \
        -rc vbr -cq $quality -qmin $quality -qmax (math $quality + 5) \
        -vf "fps=30,scale=1920:-2:flags=lanczos" \
        -c:a aac -b:a 128k \
        $output
end


