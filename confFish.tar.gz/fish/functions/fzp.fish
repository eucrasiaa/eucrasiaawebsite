function fzp
    # fd finds the files, fzf lets you pick, bat previews them
    fd --type f --hidden --exclude .git | fzf --preview 'bat --color=always --style=numbers --line-range=:500 {}'
end

