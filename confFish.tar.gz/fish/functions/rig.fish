function rig
    # We use fzf as the input prompt, and it tells rg what to find
    fzf --ansi --disabled --query "$argv" \
        --bind "change:reload:rg --column --line-number --no-heading --color=always --smart-case {q} || true" \
        --delimiter : \
        --preview 'bat --color=always --highlight-line {2} --style=numbers --line-range {2}:+50 {1}' \
        --bind "enter:become(nvim +{2} {1})"
end
# {q} is the fzf query,  --disabeld telsl rg to do most work, allows to open in editor when enter pressed
