function discord_small
    # Usage: discord_small input.mp4 [crf_num]
    set -l crf (test (count $argv) -ge 2; and echo $argv[2]; or echo 28)
    ffmpeg -y -i $argv[1] -c:v libx264 -preset slow -crf $crf \
    -vf "fps=30,scale=1280:-2" -c:a aac -b:a 96k (string replace .mp4 _tiny.mp4 $argv[1])
end
