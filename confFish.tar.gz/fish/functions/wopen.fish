# zip, rar, tar aid. both usable, and also quick ref guide

function wopen --description "Will's Lovely compressed file utility helper. cause i always forget"
  argparse 'i/info' 'q/quiet' 'h/help' 'o/overwrite' 'd/dir=' -- $argv

  or return 1

  if set -q _flag_help
    echo "Usage: wopen [FILE] [-q/--quiet NO PROMPTING UNLESS NEEDED] [-d/--dir OUTDIR] [-o/--overwrite]"
    echo "supports: .tar.gz, .tgz, .zip, .rar"
    echo "-i or --info: quick reference sheet for what utilities and flags to use!"
    return 0
  end

  if set -q _flag_info
    echo "Quick Reference Guide for Compression Utilities:"
    echo "---------------------------------------------"
    echo "1. tar.gz / tgz: tar -zxvf file.tar.gz"
    echo "  -z: actually use gzip"
    echo "  -x: extract. else, it lists contents"
    echo "  -v: verbose"
    echo "  -f: which file (must be last flag)"
    echo "2. tar.bz2 / tbz2: tar -jxvf file.tar.bz2"
    echo "  -j: bzip2"
    echo "  see above"
    echo "3. tar.xz / txz: tar -Jxvf file.tar.xz"
    echo "  -J: xz compression"
    echo "  see above"
    echo "4. zip: unzip -q file.zip (-d outdir)"
    echo "  -d specifies output directory"
    echo "  -q quiet (no output)"
    echo "5. rar: unrar x file.rar"
    echo "  'x' extracts with full paths"

    return 0
  end


  set -l file $argv[1]
  echo "!Debug: Received file argument: $file"

  # validate
  if not test -f "$file"
    set_color red; echo "WError: File '$file' not found."; set_color normal
    return 1
  end

  # 3. auto picks name of output from file. if none given 
  set -l outdir ""
  if set -q _flag_dir
    set outdir $_flag_dir
  else
    set outdir (string replace -r '\.[^.]+$' '' $file)
  end

  if test -d "$outdir"; and not set -q _flag_overwrite
    if set -q _flag_quiet
      echo "Directory exists...quiet...Aborting..."
      return 1
    end
    set_color yellow
    echo "Target directory '$outdir' already exists."
    set_color normal

    read -l -P "Action: [o]verwrite, [n]ew folder, [a]bort? " choice
    switch $choice
      case o
        echo "Proceeding with overwrite..."
      case n
        set outdir "$outdir-extracted"
        echo "Extracting to $outdir instead..."
      case '*'
        echo "Extraction aborted."
        return 1
    end
  end

  mkdir -p $outdir
  # validate
  # set -l q_flag ""
  # if set -q _flag_quiet
  #     set q_flag "-q"
  # end

  # 5. "switch em down neph" - wise man in his car
  switch $file
    case '*.tar.gz' '*.tgz' '*.tar.bz2' '*.tbz2' '*.tar.xz' '*.txz'
      tar -xvf "$file" -C "$outdir" --strip-components=1
    case '*.zip'
      set -l q_flag
      if set -q _flag_quiet; set q_flag "-q"; end
        unzip $q_flag "$file" -d "$outdir"

        # ZIP doesn't have 'strip-components', so we manually flatten if it's nested
        set -l contents (ls -1 "$outdir")
        if test (count $contents) -eq 1; and test -d "$outdir/$contents[1]"
          mv "$outdir/$contents[1]"/* "$outdir/"
          rmdir "$outdir/$contents[1]"
        end

        # case '*.tar.gz' '*.tgz'
        #     tar -zxvf $file -C $outdir
        # case '*.tar.bz2' '*.tbz2'
        #     tar -jxvf $file -C $outdir
        # case '*.tar.xz' '*.txz'
        #     tar -Jxvf $file -C $outdir
        # case '*.zip'
        #     unzip $file -d $outdir
      case '*.rar'
        unrar x $file $outdir
      case '*'
        set_color red; echo "Unsupported file type: $file"; set_color normal
        return 1
      end

      if test $status -eq 0
        set_color green; echo "Successfully extracted to $outdir"; set_color normal
        if set -q _flag_quiet
          echo "Extraction completed."
        else 
          echo "Preview:"
          eza --long --group-directories-first --color=always --icons $outdir --no-permissions | head -n 20 
        end
      else
        set_color red; echo "Extraction failed."; set_color normal
      end
  end
