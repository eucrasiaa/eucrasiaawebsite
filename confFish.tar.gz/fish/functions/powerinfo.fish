function powerinfo

  if count $argv > /dev/null
    switch $argv[1]
      case on
        enable-conservation-mode.sh
        echo (set_color green)"Conservation Mode Enabled."(set_color normal)
      case off
        disable-conservation-mode.sh
        echo (set_color yellow)"Conservation Mode Disabled."(set_color normal)
      case '*'
        # Do nothing for unknown arguments
    end
  end

  echo "---  Will my laptop die?? ---"

  # 1. Wattage Draw (The most important stat)
  set -l draw (cat /sys/class/power_supply/BAT*/power_now)
  set -l watts (math "$draw / 1000000")
  echo (set_color yellow)"Power Draw:   "(set_color normal)"$watts W"

  # 2. TLP Mode (Check if we are in AC/BAT/Manual)

  set -l tlp_data (tlp-stat -s | grep "Power" | awk '{print $4}')
  set -l tlp_profile $tlp_data[1]

  set -l tlp_power_source $tlp_data[2]
  # set -l tlp_mode (tlp-stat -s | grep "Mode" | awk '{print $3}')
  # echo (set_color cyan)"TLP Mode:     "(set_color normal)"$tlp_mode"
  echo (set_color cyan)"TLP Profile:  "(set_color normal)"$tlp_profile"
  echo (set_color cyan)"Power Source: "(set_color normal)"$tlp_power_source"

  # check lenovo laptop mode:
  # cat /sys/firmware/acpi/platform_profile)
  set -l lenovo_mode (cat /sys/firmware/acpi/platform_profile)
  # low-power,balanced,performance 
  if test "$lenovo_mode" = "low-power"
    echo (set_color cyan)"Lenovo Mode:  "(set_color normal)"LOW POWER"
  else if test "$lenovo_mode" = "balanced"
    echo (set_color white)"Lenovo Mode:  "(set_color normal)"BALANCED"
  else if test "$lenovo_mode" = "performance"
    echo (set_color red)"Lenovo Mode:  "(set_color normal)"PERFORMANCE"
  else
    echo (set_color white)"Lenovo Mode:  "(set_color normal)"UNKNOWN"
  end


  # 
  # 3. Hyprland Refresh Rate (Verify 60Hz)
  set -l hz (hyprctl monitors | grep -m 1 -oP '@[0-9\.^" "]+' | cut -d'@' -f2)
  echo (set_color blue)"Refresh Rate: "(set_color normal)"$hz"

  # 4. NVIDIA Status (Verify if it's off)
  if command -v nvidia-smi > /dev/null
    if nvidia-smi > /dev/null 2>&1
      echo (set_color red)"NVIDIA GPU:   "(set_color normal)"ON (DANGER)"
    else
      echo (set_color green)"NVIDIA GPU:   "(set_color normal)"OFF (SAFE)"
    end
  else
    echo (set_color green)"NVIDIA GPU:   "(set_color normal)"OFF (HIDDEN)"
  end

  if test -f /sys/bus/platform/drivers/ideapad_acpi/VPC2004:00/conservation_mode
    set -l cons_status (cat /sys/bus/platform/drivers/ideapad_acpi/VPC2004:00/conservation_mode)
    if test "$cons_status" = "1"
      echo (set_color green)"Battery Cons:  "(set_color normal)"ON (Capped at 80%)"
    else
      echo (set_color red)"Battery Cons:  "(set_color normal)"OFF (Charging to 100%)"
    end
  end

  # 5. Bluetooth Status
  set -l bt (bluetoothctl show | grep "Powered" | awk '{print $2}')
  if test "$bt" = "yes"
    echo (set_color magenta)"Bluetooth:    "(set_color normal)"ON"
  else
    echo (set_color green)"Bluetooth:    "(set_color normal)"OFF"
  end

  # 6. CPU Speed (Current MHz vs Cap)
  set -l mhz (grep "MHz" /proc/cpuinfo | head -n 1 | awk '{print $4}')
  echo (set_color white)"CPU Clock:    "(set_color normal)"$mhz MHz"

  #brightness check
  set -l bright (brightnessctl g)
  set -l max_bright (brightnessctl m)
  set -l perc (math "$bright / $max_bright * 100")
  echo (set_color blue)"Brightness:   $perc%"(set_color normal)

  echo "-------------------------------"
end
